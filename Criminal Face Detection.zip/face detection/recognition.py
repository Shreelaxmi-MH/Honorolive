import cv2
import os
import numpy as np
import tkinter as tk
from tkinter import filedialog

# Load pre-trained face detection model (Haar cascades)
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Initialize an empty list to store face embeddings
known_embeddings = []
known_names = []

# Function to extract face embeddings from an image
def extract_face_embedding(img_path):
    img = cv2.imread(img_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
    if len(faces) == 1:
        x, y, w, h = faces[0]
        return np.random.rand(128)  # Placeholder for actual face embedding
    else:
        return None

# Load known criminal profiles (you'll need to populate this)
# Example: Read images from a folder and extract embeddings
criminals_folder = 'criminals_images'
for filename in os.listdir(criminals_folder):
    if filename.endswith('.jpg'):
        img_path = os.path.join(criminals_folder, filename)
        face_embedding = extract_face_embedding(img_path)
        if face_embedding is not None:
            known_embeddings.append(face_embedding)
            known_names.append(filename.split('.')[0])

# Create a simple GUI for file selection
root = tk.Tk()
root.withdraw()  # Hide the main window

# Ask the user to select a file (image or video) for testing
test_file_path = filedialog.askopenfilename(title="Select Test File", filetypes=[("Image files", "*.jpg"), ("Video files", "*.mp4")])

# Initialize video capture from webcam or selected test file
if test_file_path.lower().endswith(('.mp4', '.avi', '.mov')):
    cap = cv2.VideoCapture(test_file_path)
else:
    cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()

    # Check if the frame is valid
    if not ret or frame is None or frame.size == 0:
        continue

    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray_frame, scaleFactor=1.1, minNeighbors=5)

    for (x, y, w, h) in faces:
        face_roi = gray_frame[y:y + h, x:x + w]

        # Placeholder for actual face embedding extraction (similar to known_embeddings)
        current_embedding = np.random.rand(128)

        # Compare with known_embeddings to recognize the person
        distances = [np.linalg.norm(current_embedding - known_embedding) for known_embedding in known_embeddings]
        min_distance_index = np.argmin(distances)
        min_distance = distances[min_distance_index]
        min_distance_threshold = 0.5  # Adjust this threshold as needed

        if min_distance < min_distance_threshold:
            criminal_name = known_names[min_distance_index]
            cv2.putText(frame, f'Criminal Detected: {criminal_name}', (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        else:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)  # Draw bounding box for unknown faces

    cv2.imshow('Criminal Detection', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
